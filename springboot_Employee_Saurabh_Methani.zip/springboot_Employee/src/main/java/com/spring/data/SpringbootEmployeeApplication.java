package com.spring.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@EnableAutoConfiguration
@SpringBootApplication
public class SpringbootEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootEmployeeApplication.class, args);
	}

}
