package com.spring.data.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.spring.data.domain.Employee;

import com.spring.data.service.EmpService;

@Controller
public class EmpController {
	
	@Autowired
	private EmpService empService;

	
	@RequestMapping(value = "/listEmployees", method = RequestMethod.GET)
	public ModelAndView employees() {
		List<Employee> allEmployees = empService.getAllEmployee();
		System.out.println(allEmployees);
		
		ModelAndView m = new ModelAndView();
		m.setViewName("allEmployees");
		m.addObject("allEmployees",allEmployees);
		m.addObject("msg","hello world");
		
		return m;
		//new ModelAndView("allEmployees", "employees", allEmployees)

	}

	@RequestMapping(value = "/addNewEmployee", method = RequestMethod.GET)
	public ModelAndView addNewEmployee() {

		Employee emp = new Employee();
		return new ModelAndView("newEmployee", "form", emp);

	}
	

//	handle add product form
	@RequestMapping(value = "/addNewEmployee", method = RequestMethod.POST)
	public RedirectView newEmployee(Employee employee, HttpServletRequest request) {
		
		System.out.println(employee);
		empService.createEmployee(employee);
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl(request.getContextPath() + "/listEmployees");
		
		return redirectView;
	}

	// delete handler
	@RequestMapping("/delete/{empId}")
	@ResponseBody
	public RedirectView deleteProduct(@PathVariable("empId") int empId, HttpServletRequest request) {
		System.out.println(empId);
		empService.deleteEmployee(empId);
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl(request.getContextPath() + "/listEmployees");
		
		return redirectView;
	}
	
	@RequestMapping(value = "/update/{empId}", method = RequestMethod.GET)
	public ModelAndView updateForm(@PathVariable("empId") int empId)
	{
		Employee employee = empService.getEmployee(empId);
		empService.deleteEmployee(empId);
		//model.addObject(employee);
		//model.addAttribute("employee", employee);
		System.out.println(employee);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("updateEmployee");
		mv.addObject("employee",employee);
		return mv;
	}
	
	@RequestMapping(value = "/updateEmployee", method = RequestMethod.POST)
	public RedirectView updateEmployee(Employee employee, HttpServletRequest request) {

		empService.updateEmployee(employee);
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl(request.getContextPath() + "/listEmployees");
		return redirectView;

	}

}
