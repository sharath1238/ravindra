package com.spring.data.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.spring.data.domain.Employee;


@Repository
public interface EmpRepository extends CrudRepository<Employee,Integer> {

}
