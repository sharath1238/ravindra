package com.spring.data.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import com.spring.data.domain.Employee;
import com.spring.data.repository.EmpRepository;

@Service
public class EmpService {

	@Autowired
	private EmpRepository empData;
	
	public Employee createEmployee(Employee emp) {
		
		System.out.println(emp);
		return empData.save(emp);
	}
	
	public List<Employee> getAllEmployee() {
		return (List<Employee>) empData.findAll();
	}
	
	public void deleteEmployee(int eid) {
		
		empData.deleteById(eid);
	}
	
	public Employee getEmployee(int eid) {
		return empData.findById(eid).orElse(null);
	}
	
	public Employee updateEmployee(Employee emp) {
		
		
		//empData.deleteById(emp.getEmpId());
		return empData.save(emp);
	}
	
	
}
