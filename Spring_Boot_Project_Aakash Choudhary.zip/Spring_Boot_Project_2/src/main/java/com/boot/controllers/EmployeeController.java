package com.boot.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.boot.data.EmployeeRepository;
import com.boot.model.Employee;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeData;

	@GetMapping("/signup")
	public String employeeCreation(Employee employee) {
		return "add-employee";
	}

	@PostMapping("/createEmployee")
	public String createEmployee(Employee employee) {
		employeeData.save(employee);
		return "redirect:/index";
	}

	@GetMapping("/index")
	public String retrieveUsers(Model model) {
		model.addAttribute("employees", employeeData.findAll());
		return "index";
	}

	@GetMapping("/edit/{empId}")
	public String showUpdateForm(@PathVariable("empId") int empId, Model model) {
		Employee employee = employeeData.findById(empId).orElse(null);

		model.addAttribute("employee", employee);
		return "update-employee";
	}

	@PostMapping("/updateEmployee/{empId}")
	public String updateEmployee(@PathVariable("empId") int empId, Employee employee) {
		employeeData.save(employee);
		return "redirect:/index";
	}

	@GetMapping("/delete/{empId}")
	public String deleteUser(@PathVariable("empId") int empId) {
		Employee employee = employeeData.findById(empId)
				.orElseThrow(() -> new IllegalArgumentException("Invalid EmpId:" + empId));
		employeeData.delete(employee);
		return "redirect:/index";
	}

}